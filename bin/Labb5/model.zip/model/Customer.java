package lab5.model;

import java.util.Random;

public class Customer {

	private int ID; 
	private double buyTime;
	private double payTime;
	public Customer(int ID, double P[], double K[], long seed) {
		this.ID = ID;
		Random random = new Random(seed);
		buyTime = (double) ((Math.random() * (P[0] + P[1])) / 2);
		payTime = (double) ((Math.random() * (K[0] + K[1])) / 2);
	}

	public int getID() {
		return ID;
	}
	
	public double getBuyTime() {
		return buyTime;
	}
	
	public double getPayTime() {
		return payTime;
	}
}
