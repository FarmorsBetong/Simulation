package lab5.model.event;

import lab5.model.CashRegisterState;

public class StopEvent extends StartEvent{

	/*Lägg i nödbromsen*/
	public StopEvent(CashRegisterState item) {
		item.emergencyStop = true;
		
	}

}
