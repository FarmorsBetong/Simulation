package lab5.model.event;

import lab5.model.CashRegisterState;

public class ShoppingEvent extends StartEvent{

	
	
	
/*
 * Hur lång tid tar det att betala varor?
 * skapa en betalhändelse.
 * om det finns lediga kassor gå direkt till betalhändelse.
 * annars ställs i FIFO kö
 * */
	
	public ShoppingEvent(CashRegisterState item, int ID) {
		item.eventName = "Shopping: ";
		double TimeStamp = item.getCustomerPayTime(ID);
		
		SortedSequence.add(new PaymentEvent(item, ID), TimeStamp, ID);
		
	}
	

}
