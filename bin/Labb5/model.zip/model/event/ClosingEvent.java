package lab5.model.event;

import lab5.model.CashRegisterState;
public class ClosingEvent extends StartEvent{

	
	/*
	 * Stäng butiken
	 * */
	public ClosingEvent(CashRegisterState item) {
		item.eventName = "Closing: ";
		item.isOpen = false;
	}

}
