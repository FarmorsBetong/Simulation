package lab5.model.event;

import lab5.model.Customer;
import lab5.simulator.SortedSequence;
import lab5.model.CashRegisterState;
public class ArrivalEvent extends StartEvent{

	
	/* Är snabbköpet öppet ? 
	 * Är det fullt? 
	 * skapa en ny kund.
	 * skapa plockhändelse
	 * * Hur lång tid tar det att ploka varor?
	 * om öppet skape en ny ankomsthändelse
	 * 
	 * */
	public ArrivalEvent(CashRegisterState item) {
		
		item.totalAmountOfCustomers++;
		if(item.getIsOpen()) {
			if (item.getPeopleInStore() < item.getMaxPeople()) {
				item.eventName = "Arrival: ";
				Customer customer = new Customer(item.CustomerID.size(), item.getP(), item.getK(), item.getSeed());
				item.CustomerID.add(customer);
				double Timestamp = customer.getBuyTime();
							
				SortedSequence.add(new ShoppingEvent(item,customer.getID()),Timestamp,customer.getID());
			}
			else {
				item.missedCustomers++;
			}
			
			double arrTime = Math.random()* 1/ item.getLambda();
			SortedSequence.add(new ArrivalEvent(item), arrTime);
		}
	}

}
