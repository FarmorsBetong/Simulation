package lab5.model.event;

import lab5.simulator.Event;
import lab5.model.CashRegisterState;
public class StartEvent extends Event{

	/*
	 * Lägg ur nödbromsen
	 * öppna butiken
	 * skapa en ankomsthändelse.
	 * */
	public StartEvent() {
		item.eventName = "Start";
		item.emergencyStop = false;
		item.isOpen = true;
		double arrTime = Math.random()* 1/ item.getLambda();
		EventQueue.add(new ArrivalEvent(item), arrTime);
		Sort
	}
}