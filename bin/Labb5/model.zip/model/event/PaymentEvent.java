package lab5.model.event;

import lab5.model.CashRegisterState;

public class PaymentEvent extends StartEvent{

	
	
	/*
	 *TODO Hur lång tid tar det att betala?
	 *TODO minska antal människor i butiken
	 *TODO om det är någon i FIFO kön ta den personen.
	 * */
	public PaymentEvent(CashRegisterState item) {
		item.eventName = "Payment: ";
		item.peopleInStore--;
		if(!item.isLineEmpty()) {
			
		}
		else {
			
		}
	}

}
