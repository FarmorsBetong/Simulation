package lab5.model;

import java.util.ArrayList;

import lab5.simulator.State;

/**
 * 
 * @author wesjon-5, 
 *
 */
public class CashRegisterState extends State{
 // TODO Fix the casher variables.
	private int maxPeople = 0;
	private int lambda;
	private double[] P = new double[2]; 
	private double[] K = new double[2]; 
	private long seed;
	public FIFO inLine = new FIFO();
	public int peopleInStore = 0;
	public int totalAmountOfCustomers = 0;
	public int missedCustomers = 0;
	public String eventName = "";
	public ArrayList<Customer> CustomerID = new ArrayList<Customer>();
	public boolean isOpen = false;
	public Cashier cashier = new Cashier();
	
	/**
	 * @param cashiers How many cashiers is there in the store.
	 * @param maxPeople Max amount of people in the store.
	 * @param lambda Time divider.
	 * @param P Between what time variables dose it take for a customer to pick products.
	 * @param K Between what time variables dose it take for a customer to pay.
	 * @param seed The seed for how all the randomizes operate on.
	 */
	
	public CashRegisterState(int cashiers, int maxPeople, int lambda, double[] P, double[] K,int seed) {
		cashier.used = cashiers;
		this.maxPeople = maxPeople;
		this.lambda = lambda;
		this.P = P;
		this.K = K;
		this.seed = seed;
		
	}

	//All the getClasses
	/**
	 * @return The max numbers of people allowed in the store.
	 */
	public int getMaxPeople() {
		return maxPeople;
	}
	
	public int getLambda() {
		return lambda;
	}
	
	public double[] getP(){
		return P;
	}
	
	public double[] getK(){
		return K;
	}
	/**
	 * @return The programs seed.
	 */
	public long getSeed() {
		return seed;
	}
	
	/**
	 * @return The next person in line to pay.
	 */
	public int getNextInLine() {
		return inLine.first();
	}
	
	/**
	 * Removes the first person in the line.
	 */
	public void removeInLine() {
		inLine.removeFirst();
	}
	
	/**
	 * @return True if the line is empty else false.
	 */
	public boolean isLineEmpty() {
		return inLine.isEmpty();
	}
	
	/**
	 * @return The amount of people in the store right now.
	 */
	public int getPeopleInStore() {
		return peopleInStore;
	}
	
	/**
	 * @return The total amount of customers that have arrived to the store.
	 */
	public int getTotalOfCustormers() {
		return totalAmountOfCustomers;
	}
	
	/**
	 * @return The amount of missed customers.
	 */
	public int getMissed() {
		return missedCustomers;
	}
	
	/**
	 * @return The name of the current event.
	 */
	public String getEventName() {
		return eventName;
	}
	
	/**
	 * 
	 * @param i
	 * @return The last customer.
	 */
	public int getCustomerID(int i){
		return CustomerID.get(i).getID();
	}
	
	/** 
	 * @param i
	 * @return The time it takes for this customer to pick products.
	 */
	public double getCustomerBuyTime(int i) {
		return CustomerID.get(i).getBuyTime();
	}
	
	/**
	 * 
	 * @param i
	 * @return The time it takes for this customer to pay for the products.
	 */
	public double getCustomerPayTime(int i) {
		return CustomerID.get(i).getPayTime();
	}
	/**
	 * @return Is the store open.
	 */
	public boolean getIsOpen() {
		return isOpen;
	}
	
	
	
	
	
	
	
	
	
}
