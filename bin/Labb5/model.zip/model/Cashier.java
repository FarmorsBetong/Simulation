package lab5.model;
class Cashier {

	public int used; 
	double noneffectiveCashierTime = 0.0;
	
	public Cashier() {
		
	}
	
	public int getUsed() {
		return used;
	}
	public double getCashierTime() {
		return noneffectiveCashierTime;
	}
}
