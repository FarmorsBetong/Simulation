package lab5.model;

import java.util.ArrayList;
import java.util.NoSuchElementException;
/**
 * 
 * @author wesjon-5
 *
 *	This program gives the basis for an "First in first out" program.
 *
 */

class FIFO{
	private int maxSize = 0;
	ArrayList<Integer> queue = new ArrayList<Integer>();
	
	/*Returns the size of queue.*/
	public int size() {
		return queue.size();
	}

	/*Return the max size queue have ever had.*/
	public int maxSize() {
		return maxSize;
	}
	
	/*Checks if queue is empty.*/
	public boolean isEmpty() {
		return queue.size() == 0;
	}
	
	/*Returns the first object in queue.*/
	public Integer first() {
		if(queue.size()== 0 ) {
			throw new NoSuchElementException("There are no elements in queue(First)");
		}
		return queue.get(0);
	}

	/*Returns a String that says what is in a queue.*/
	public String toString() {
		String string = "Queue: ";
		
		for (int elem= 0; elem < queue.size(); elem++) {
			string += "(" + String.valueOf(queue.get(elem)) + ") ";
		}	
		return string;
	}
	
	/*Adds objects at the last position in a queue.*/
	public void add(Integer item) {
		queue.add(item);
		if (queue.size() > maxSize) {
			maxSize = queue.size();
		}
	}
	
	/*Removes the first object in a queue.*/
	public void removeFirst(){
		if(queue.size()== 0 ) {
			throw new NoSuchElementException("There are no elements in queue(Remove First)");
		}
		queue.remove(0);
	}
}